//
//  Member.swift
//  Assignment5
//
//  Created by Noah Rushing on 10/29/22.
//

import Foundation

struct Member2: Identifiable, Codable {
    let id: UUID
    let name: String
}
